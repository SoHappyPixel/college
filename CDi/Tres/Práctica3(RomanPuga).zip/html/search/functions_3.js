var searchData=
[
  ['main',['main',['../class_c_di_1_1_tres_1_1_main1.html#a5aee730c1e20de45bcd7c479e5e19dcb',1,'CDi.Tres.Main1.main()'],['../class_c_di_1_1_tres_1_1_main2.html#af4289e02295a2842d736cb6344affddf',1,'CDi.Tres.Main2.main()']]]
];
